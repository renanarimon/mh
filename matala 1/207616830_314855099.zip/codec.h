#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int addOne(int x);
int subtractOne(int x);
char *encode(char *src, char *dst, int len);
char *decode(char *src, char *dst, int len);
